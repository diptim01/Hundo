﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hundo_P.Models
{
    public class DaysOftheWeek
    {
        enum DaysoftheWeek
        {
            Sunday = 1,
            Monday,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday

        }
    }
}